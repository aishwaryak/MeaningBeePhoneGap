/**
 * 
 */
var urlString = "http://127.0.0.1:8000";
urlString = "http://ec2-54-148-143-69.us-west-2.compute.amazonaws.com:8000";